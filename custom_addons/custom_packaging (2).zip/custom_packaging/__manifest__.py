{
    'name': 'Custom Packaging',
    'version': '1.0',
    'summary': 'Packaging lines for products (one2many table)',
    'depends': ['product'],
    'data': [
        'views/product_template_views.xml',
    ],
    'installable': True,
    'application': False,
}
