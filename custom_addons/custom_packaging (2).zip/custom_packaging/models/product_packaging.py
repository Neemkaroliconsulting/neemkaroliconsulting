from odoo import models, fields, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    # One2many relation to packaging lines
    packaging_line_ids = fields.One2many(
        'product.packaging.line',
        'product_tmpl_id',
        string="Packaging Lines"
    )

    # Optional individual summary fields
    packaging_length = fields.Float(string="Packaging Length (cm)")
    packaging_width = fields.Float(string="Packaging Width (cm)")
    packaging_height = fields.Float(string="Packaging Height (cm)")
    packaging_cbm = fields.Float(
        string="Packaging Volume (CBM)",
        compute="_compute_packaging_cbm",
        store=True
    )

    @api.depends('packaging_length', 'packaging_width', 'packaging_height')
    def _compute_packaging_cbm(self):
        for record in self:
            if record.packaging_length and record.packaging_width and record.packaging_height:
                record.packaging_cbm = (
                    record.packaging_length * record.packaging_width * record.packaging_height
                ) / 1000000.0
            else:
                record.packaging_cbm = 0.0
